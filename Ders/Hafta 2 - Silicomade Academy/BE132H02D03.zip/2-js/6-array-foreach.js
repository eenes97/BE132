var ogrenciler = ["Ahmet", "Mehmet", "Ayşe", "Fatma"];


ogrenciler.forEach((ogrenci) => {
    console.log(ogrenci);
});


console.log("------------");

ogrenciler.forEach(yazdir);


function yazdir(ogrenci){
    console.log(ogrenci);
}


/*
["Ahmet", "Mehmet", "Ayşe", "Fatma"];

"Ahmet" -> yazdir("Ahmet")
"Mehmet" -> yazdir("Mehmet")
"Ayşe" -> yazdir("Ayşe")
"Fatma" -> yazdir("Fatma")  



*/


var ogrenciler2 = [
    { ad: "Ahmet", soyad: "Yılmaz", yas: 20 },
    { ad: "Mehmet", soyad: "Kaya", yas: 22 },
    { ad: "Ayşe", soyad: "Demir", yas: 15 },
    { ad: "Fatma", soyad: "Çelik", yas: 17 }
];


ogrenciler2.forEach((ogrenci) => {
    if(ogrenci.yas >= 18){
        console.log(ogrenci.ad + " " + ogrenci.soyad + " 18 yaşından büyüktür.");
    }
});


//todo: bunları araştırın (map, filter, reduce, sort)