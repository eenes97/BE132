let isim = "abdurrahman";
let yas = 20;
let aktifMi = true;

let ogrenci = {
    ad: "mustafa",
    yas: 42,
    selamVer(){
        console.log("merhaba ben", this.ad, "yasim", this.yas);
    }
}

let sehirler = ["istanbul", "ankara", "izmir"];

let sinif; //undefined
let meslek = null; //null
