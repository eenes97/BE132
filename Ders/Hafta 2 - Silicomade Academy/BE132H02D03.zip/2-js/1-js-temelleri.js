//1. JS Değişken tanımlama




//let ile değişken tanımlanır
let a = 10; //number

let isim = "evin"; //string
let mevcut = true; //bool

isim = "enes";

//const ile değişken tanımlanır
const sinifAdi = "BE132";


//2. Aritmetik işlemler

let sayi1 = 10;
let sayi2 = 12;
let toplam = sayi1 + sayi2;
console.log(toplam);


//3. Mantıksal İşlemler
let c = 10 == "10"; //deger kontrolü
let d = 10 === "10"; //tip kontrolü
console.log(c);
console.log(d);


//4. Koşul blokları
if(toplam > 25){
    console.log("sayi 25'den büyük");
}
else if(toplam > 20){
    console.log("sayi 20'den büyük");
}
else{
    console.log("sayi 20'den küçük");
}


//5. Döngüler

//while döngüsü
let i = 0;
while(i < 5){
    console.log(i);
    i++;
}

console.log("--------")

for(let i = 0; i < 5; i++){
    console.log(i);
}

//Fonksiyonlar
function selamVer(isim){
    console.log("merhaba", isim);
}

selamVer("kemal");
selamVer("arda");


//fonksiyon tanımı
function topla(s1, s2){
    return s1 + s2;
}

let toplam2 = topla(2, 5);

console.log(toplam2);


//fonksiyonu değişken olarak tanımlama
let carp = function(s1, s2){
    return s1 * s2;
}

let carpim = carp(10, 3);
console.log(carpim);


//arrow function olarak tanımlama
let cikar = (s1, s2) => {
    return s1 - s2;
}

let fark = cikar(10, 3);
console.log(fark);