
selamVer(); // hata vermez

// Fonksiyon tanımlama (Function Declaration)
function selamVer(isim="BE132"){
    console.log("Merhaba " + isim);
}


function topla(a, b){
    return a + b;
}


let sonuc = topla(5, 10); 

// cikarma(10, 5); // hata verir

// Fonksiyon ifadesi (Function Expression)
let cikarma = function(a, b){
    return a - b;
}

cikarma(2, 4); // -2  

// Ok fonksiyonu (Arrow Function)
let cikarma2 = (a, b) => {
    return a - b;
}

cikarma2(2, 4); // -2  

