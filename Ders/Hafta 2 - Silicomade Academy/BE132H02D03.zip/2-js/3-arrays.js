let sayilar = [5, 7, 12, 4];

// console.log(sayilar[0]); // 5
// sayilar[1] = 10;
// console.log(sayilar[1]); // 10


console.log(sayilar.length); // 4

sayilar.push(20); // sayilar dizisinin sonuna 20 ekler
console.log(sayilar); // [5, 7, 12, 4, 20]

sayilar.pop(); // sayilar dizisinin son elemanını çıkarır
console.log(sayilar); // [5, 7, 12, 4]

sayilar.unshift(1); // sayilar dizisinin başına 1 ekler
console.log(sayilar); // [1, 5, 7, 12, 4]

sayilar.shift(); // sayilar dizisinin başındaki elemanı çıkarır
console.log(sayilar); // [5, 7, 12, 4]


let isimler = ["ali", "ayşe", "mehmet"];
let varMi = isimler.includes("ayşe"); // true
console.log(varMi); // true

let index = isimler.indexOf("mehmet"); // 2
console.log(index); // 2