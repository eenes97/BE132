//TODO: JS Promise ve async/await konusunu araştır 


const url = 'https://jsonplaceholder.typicode.com/users';

const ul = document.getElementById('liste');

fetch(url)
    .then(response => response.json())
    .then((data) => {
        data.forEach(user => {
            const li = document.createElement('li');
            li.textContent = user.username;
            ul.appendChild(li);
        });
    });


