console.log("Script başladı");

setTimeout(() =>{
    console.log("2 saniye sonra çalıştı");
}, 2000);

console.log("Script bitti");
