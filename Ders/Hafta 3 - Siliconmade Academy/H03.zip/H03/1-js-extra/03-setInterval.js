console.log("Başladı");


let counter = 1;

const intervalId = setInterval(() => {
    console.log(counter);
    counter++;  
}, 500);


function stopInterval() {
    clearInterval(intervalId);
    console.log("Interval durduruldu.");
}

const durdurBtn = document.getElementById("durdurBtn");
durdurBtn.addEventListener("click", stopInterval);